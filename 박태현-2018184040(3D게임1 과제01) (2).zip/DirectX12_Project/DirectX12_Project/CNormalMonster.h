#pragma once
class CNormalMonster
{
};

