#include "CSmartPointerFactory.h"
