#include "CDelegate.h"
