#include "CNormalMonster.h"
