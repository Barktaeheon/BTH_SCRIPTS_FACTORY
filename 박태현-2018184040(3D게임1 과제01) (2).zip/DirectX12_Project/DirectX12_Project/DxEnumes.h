#pragma once


enum SCENE {
	SCENE_LOGO, SCENE_GAME, SCENE_NON
};