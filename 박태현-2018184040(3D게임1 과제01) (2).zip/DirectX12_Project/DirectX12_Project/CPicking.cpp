#include "CPicking.h"

void CPicking::Free()
{
}

HRESULT CPicking::NativeConstruct(const RECT& _tDesc)
{
    return E_NOTIMPL;
}

void CPicking::Tick_RayInWorldSpace(CGameInstance* _pGameInstance)
{
}
